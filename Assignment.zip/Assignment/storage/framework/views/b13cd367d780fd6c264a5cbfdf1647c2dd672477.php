  <!-- Main Sidebar Container -->
   <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="<?php echo e(route('home')); ?>"><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('users.index')); ?>"> <i class="menu-icon fa fa-users"></i>Users</a>
                    </li>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>
<?php /**PATH C:\xampp\htdocs\logicstreak\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>