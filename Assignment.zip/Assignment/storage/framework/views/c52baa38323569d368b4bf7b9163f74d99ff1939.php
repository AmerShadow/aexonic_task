<!-- Navbar -->
     <!-- Header-->
        <header id="header" class="header">
            <div class="top-left">
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Admin</a>
                    <a class="navbar-brand hidden" href="<?php echo e(route('home')); ?>">Admin</a>
                    <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            <div class="top-right">
                <div class="header-menu">

                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="<?php echo e(asset('svg/admin.jpg')); ?>" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <form method="post" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="dropdown-item"  type="submit"><i class="fa fa-power -off"></i>Logout
                    </button>
                </form>
                        </div>
                    </div>

                </div>
            </div>
        </header>
        <!-- /#header --><?php /**PATH C:\xampp\htdocs\LogistreakAssignment\resources\views/partials/navbar.blade.php ENDPATH**/ ?>