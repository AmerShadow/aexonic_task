<?php $__env->startSection('content'); ?>

  <div class="col-lg-8">
                    <div class="card">
                        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      <div class="card-header"><strong>ADD NEW USER</strong></div>
                        <div class="card-body card-block">
                            <form method="POST" action="<?php echo e(route('users.store')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                     <div class="form-group">
                        <label for="exampleInputName">Select Role:</label>
                            <select class="form-control select2" name="role">
                                      <option value="admin">Admin</option>
                                      <option value="normal_user">Normal User</option>
                            </select>
                     </div>           
                     <div class="form-group">
                         <label for="company" class=" form-control-label">User Name</label>
                        <input type="text" id="name" name="name" placeholder="User name" class="form-control">
                     </div>

                     <div class="form-group">
                        <label for="vat" class=" form-control-label">Email</label>
                        <input type="email" id="email" name="email" placeholder="Email" class="form-control">
                     </div> 
                     <div class="form-group">
                        <label for="vat" class=" form-control-label">Password</label>
                        <input type="password" id="password" name="password" placeholder="Password" class="form-control">
                     </div> 

                     <div class="form-group">
                        <label for="exampleInputName">Select Gender:</label>
                            <select class="form-control select2" name="gender">
                                      <option value="Male">Male</option>
                                      <option value="Female">Female</option>
                            </select>
                     </div>
                      <div class="form-group">
                        <label for="exampleInputName">Select Hobbies:</label>
                            <select class="form-control" name="hobbies[]" multiple="">
                                      <option value="coding">Coding</option>
                                      <option value="playing">Playing</option>
                                      <option value="singing">Signing</option>
                                      <option value="reading">Reading</option>
                                      <option value="travelling">Travelling</option>
                                      
                            </select>
                     </div>
                     <div class="form-group">
                        <label for="vat" class=" form-control-label">Profile Picture</label>
                        <input type="file" id="image" name="profile_picture" placeholder="Image" class="form-control">
                     </div> 

                     <div class="card">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                        
                    </form>                                      
                 </div>
                 </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Assignment\resources\views/admin/create.blade.php ENDPATH**/ ?>