@extends('layouts.layout')
@section('content')

 <div class="col-md-6">
            <h3 class="card-title">Product Details:</h3>
 </div>
<div class="list-group">
        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Product Name</div>
                <div class="col-md-8">{{ $user->product_name }}</div>
            </div>
        </div>

        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Prdoct Code</div>
                <div class="col-md-8">{{ $user->product_code }}</div>
            </div>
        </div>


        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Quantity</div>
                <div class="col-md-8">{{ $user->quantity }}</div>
            </div>
        </div>

        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Price</div>
                <div class="col-md-8">{{ $user->price }}</div>
            </div>
        </div>

        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Brand</div>
                <div class="col-md-8">{{ $user->brand }}</div>
            </div>
        </div>


        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Size</div>
                <div class="col-md-8">{{ $user->size }}</div>
            </div>
        </div>


        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Description</div>
                <div class="col-md-8">{{ $user->description }}</div>
            </div>
        </div>


        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">user Image</div>
                <div class="col-md-4"><img src="{{asset('uploads/productimage/'.$user->image)}}" class="img img-fluid img-thumbnail"></div>
            </div>
        </div>

        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Created At</div>
                <div class="col-md-8">{{ $user->created_at }}</div>
            </div>
        </div>

        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Updated At</div>
                <div class="col-md-8">{{ $user->updated_at }}</div>
            </div>
        </div>
    </div>

@endsection
